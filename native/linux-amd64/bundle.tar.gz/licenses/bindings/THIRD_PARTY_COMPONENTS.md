# Third-party components bundled by pylibseekdb

This inventory covers the components added by the bindings layer.
The seekdb engine's own components are listed in
`licenses/THIRD_PARTY_COMPONENTS.md` next to this directory.

- Project: `pylibseekdb`
- Version: `1.4.1.post2`
- License: `Apache-2.0`

| Component | Version | Upstream source | Packaged as | License | Modified | License text | Redistribution |
| --- | --- | --- | --- | --- | --- | --- | --- |
| libaio | 0.3.112 | https://pagure.io/libaio | Shared library shipped in the SDK and the pylibseekdb wheel (bin/libaio.so.1) | LGPL-2.1-only | No local patch recorded | `bindings/libaio/COPYING` | Retain the LGPL-2.1 text and copyright notice; the shared library is replaceable by the user. |
| MariaDB Connector/C | 3.4.8 | https://github.com/mariadb-corporation/mariadb-connector-c | Statically linked into libseekdb.so in the pylibseekdb wheel | LGPL-2.1-only | No local patch recorded | `bindings/mariadb-connector-c/COPYING.LIB` | Retain the LGPL-2.1 text and the copyright notice. Connector/C is statically linked into libseekdb.so, so LGPL-2.1 section 6 applies: a distributor must accompany libseekdb with the complete corresponding source of Connector/C (or a written offer for it) and with the materials needed to relink libseekdb with a modified Connector/C, such as the object files or an equivalent build recipe, or otherwise satisfy section 6. Letting the user replace the shipped libseekdb.so with a compatible build is permitted, but does not by itself meet the relink requirement. |
| nanobind | 2.13.0 | https://github.com/wjakob/nanobind | Statically linked into the pylibseekdb extension | BSD-3-Clause | No local patch recorded | `bindings/nanobind/LICENSE` | Retain the copyright notice, the three conditions and the disclaimer in source and binary redistributions; do not use the names of the authors to endorse derived products. |
| OpenSSL | 3.5.9 | https://github.com/openssl/openssl | Statically linked into libseekdb.so via mariadb-connector-c | Apache-2.0 | No local patch recorded | `bindings/openssl/LICENSE.txt` | Retain the Apache-2.0 license text and copyright notices. |
| zlib | 1.3.1 | https://zlib.net/ | Vendored in mariadb-connector-c and statically linked into libseekdb.so | Zlib | No local patch recorded | `bindings/zlib/LICENSE` | Retain the notice, do not misrepresent origin, and mark altered source versions. |

The original license texts are under `licenses/bindings/<component>/`.
`REDISTRIBUTION.md` describes the per-component retention and
source/relink requirements.
