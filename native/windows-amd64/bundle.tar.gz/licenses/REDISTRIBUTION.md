# Redistribution requirements

This file is generated from the per-component `METADATA.json` files.
Preserve the complete compliance directory when redistributing a package
that contains these components.  License and notice texts must remain
verbatim.

| Component | Files to retain | Redistribution requirement | Source |
| --- | --- | --- | --- |
| Abseil | `abseil-cpp/abseil-LICENSE.txt` | Retain the license and applicable notices; mark any modified files. | https://github.com/abseil/abseil-cpp/tree/20211102.0 |
| aho-corasick | `aho-corasick/rust-aho-corasick-1.1.5.txt` | Retain the MIT text and the Unlicense notice; the component is dual licensed. | https://github.com/BurntSushi/aho-corasick |
| ANTLR4 | `antlr4/antlr4-LICENSE.txt` | Retain the copyright, conditions, and disclaimer. | https://github.com/antlr/antlr4 |
| bit-set | `bit-set/rust-bit-set-0.8.0.txt` | Retain the MIT and Apache-2.0 texts and copyright notices. | https://github.com/contain-rs/bit-set |
| bit-vec | `bit-vec/rust-bit-vec-0.8.0.txt` | Retain the MIT and Apache-2.0 texts and copyright notices. | https://github.com/contain-rs/bit-vec |
| Boost | `boost/boost-geometry-1.74-LICENSE_1_0.txt`<br>`boost/boost-geometry-notices.txt` | Retain the license and all copyright/modification notices; no source or relink offer is required for unmodified binaries. | https://archives.boost.io/release/1.74.0/source/boost_1_74_0.tar.bz2 |
| chrono | `chrono/rust-chrono-0.4.45.txt` | Retain the supplied dual-license texts; no source or relink offer is required for unmodified binaries. | https://github.com/chronotope/chrono |
| cpuinfo | `cpuinfo/cpuinfo-LICENSE.txt` | Retain the copyright, conditions, and disclaimer. | https://github.com/pytorch/cpuinfo |
| CRoaring | `croaring/croaring-LICENSE.txt` | Retain the supplied dual-license text and copyrights; no source or relink offer is required for unmodified binaries. | https://github.com/RoaringBitmap/CRoaring/tree/v3.0.0 |
| curl | `curl/curl-COPYING.txt`<br>`curl/curl-inet_ntop-ISC-notice.txt` | Retain the curl copyright and permission notice; review any bundled documentation and third-party notices for the exact build. | https://github.com/curl/curl/tree/curl-8_12_1 |
| cxx | `cxx/rust-cxx-1.0.202.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/dtolnay/cxx |
| fancy-regex | `fancy-regex/rust-fancy-regex-0.20.0.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/fancy-regex/fancy-regex |
| fast-float2 | `fast-float2/rust-fast-float2-0.2.4.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/Alexhuszagh/fast-float-rust |
| fmt | `fmt/fmt-LICENSE.txt` | Retain the copyright and permission notice. | https://github.com/fmtlib/fmt |
| GCC libgomp | `gcc-libgomp/COPYING3`<br>`gcc-libgomp/COPYING.RUNTIME` | Retain the GPL-3.0 text and the GCC Runtime Library Exception. The exception permits linking libgomp into the engine without imposing GPL on the combined work, provided the exception notice is retained. | https://gcc.gnu.org/ |
| getrandom | `getrandom/rust-getrandom-0.4.3.txt` | Retain the supplied dual-license texts and any applicable notices. Only the version with a staged text is listed here. | https://github.com/rust-random/getrandom |
| globset | `globset/rust-globset-0.4.18.txt` | Retain the supplied texts; using the MIT option requires its copyright and permission notice. | https://github.com/BurntSushi/ripgrep/tree/master/crates/globset |
| IANA timezone-derived C sources | `iana-timezone-derived-c-sources/timezone-public-domain.txt` | Preserve the public-domain and contributor notices; no SPDX identifier is asserted for this dedication. | https://www.iana.org/time-zones |
| jemalloc | `jemalloc/COPYING` | Retain the copyright, conditions, and disclaimer. | https://github.com/jemalloc/jemalloc |
| LAPACK | `lapack/lapack-LICENSE.txt` | Retain the copyright, conditions, and disclaimer. | https://github.com/Reference-LAPACK/lapack |
| libaio | `libaio/libaio-COPYING.txt` | Retain the LGPL-2.1 text. Provide the corresponding libaio source, any patches, and a verified relink/replacement mechanism when bundling the library; see SOURCE-OFFER.txt. See `SOURCE-OFFER.txt`. | https://pagure.io/libaio |
| libc | `libc/rust-libc-0.2.189.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/rust-lang/libc |
| libm | `libm/libm.txt` | Retain the copyright and permission notice, including the musl-derived attribution. | https://github.com/rust-lang/compiler-builtins |
| LLVM OpenMP | `llvm-openmp/openmp-LICENSE.TXT.txt` | Retain the Apache-2.0 and LLVM exception notices. | https://github.com/llvm/llvm-project |
| log | `log/rust-log-0.4.34.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/rust-lang/log |
| memchr | `memchr/rust-memchr-2.8.3.txt` | Retain the supplied texts; using the MIT option requires its copyright and permission notice. | https://github.com/BurntSushi/memchr |
| mio | `mio/rust-mio-1.2.3.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/tokio-rs/mio |
| nlohmann-json | `nlohmann-json/nlohmann-json-LICENSE.MIT.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/nlohmann/json/tree/v3.11.3 |
| OpenBLAS | `openblas/openblas-LICENSE.txt` | Retain the copyright, conditions, disclaimer, and non-endorsement term; source patches are recorded in the source repository. | https://github.com/OpenMathLib/OpenBLAS/tree/v0.3.23 |
| OpenSSL | `openssl/openssl-LICENSE.txt` | Retain the OpenSSL and original SSLeay license texts and the required acknowledgments. | https://github.com/openssl/openssl/tree/OpenSSL_1_1_1u |
| OpenSSL 3 | `openssl-3/LICENSE.txt`<br>`openssl-3/AUTHORS.txt` | Retain the Apache-2.0 text and the AUTHORS list shipped with the binaries. | https://github.com/openssl/openssl/tree/openssl-3.6.1 |
| prost | `prost/rust-prost-0.14.3.txt` | Retain the license and applicable notices; mark modified files. | https://github.com/tokio-rs/prost |
| pthreads4w | `pthreads4w/LICENSE.txt` | Retain the Apache-2.0 text; pthread.h carries the Pthreads4w copyright notice. | https://sourceforge.net/projects/pthreads4w/ |
| quick-xml | `quick-xml/rust-quick-xml-0.41.0.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/tafia/quick-xml |
| regex-automata | `regex-automata/rust-regex-automata-0.4.18.txt` | Retain the MIT and Apache-2.0 texts and copyright notices. | https://github.com/rust-lang/regex |
| regex-syntax | `regex-syntax/rust-regex-syntax-0.8.11.txt` | Retain the MIT and Apache-2.0 texts and copyright notices. | https://github.com/rust-lang/regex |
| ring | `ring/rust-ring-0.17.14.txt` | Retain the complete file, including BoringSSL, once_cell, and fiat notices; Apache and ISC obligations are cumulative for the included code. | https://github.com/briansmith/ring |
| robin-map | `robin-map/robin-map-LICENSE.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/Tessil/robin-map/tree/v1.4.0 |
| rustls | `rustls/rust-rustls-0.23.46.txt` | Retain the supplied alternative-license texts and the notice for the selected option. | https://github.com/rustls/rustls |
| rustls-pki-types | `rustls-pki-types/rust-rustls-pki-types-1.15.1.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/rustls/pki-types |
| ryu | `ryu/rust-ryu-1.0.23.txt` | Retain the supplied alternative-license texts and applicable notices. | https://github.com/dtolnay/ryu |
| s2rst | `s2rst/rust-s2rst-0.5.1.txt` | Retain both the license and the embedded NOTICE, including Google S2 attribution; mark modified files. | https://github.com/torgebo/s2rst |
| serde | `serde/rust-serde-1.0.229.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/serde-rs/serde |
| serde_json | `serde-json/serde_json.txt` | Retain the supplied copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/serde-rs/json |
| simsimd | `simsimd/rust-simsimd-6.5.16.txt` | Retain the license and applicable notices; mark modified files. | https://github.com/ashvardanian/SimSIMD |
| slab | `slab/rust-slab-0.4.12.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/tokio-rs/slab |
| socket2 | `socket2/rust-socket2-0.6.5.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/rust-lang/socket2 |
| spdlog | `spdlog/spdlog-LICENSE.txt` | Retain the copyright and permission notice. | https://github.com/gabime/spdlog |
| spdlog-rs | `spdlog-rs/rust-spdlog-rs-0.5.3.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/SpriteOvO/spdlog-rs |
| thread-pool | `thread-pool/thread-pool-LICENSE.txt` | Retain the copyright and permission notice. | https://github.com/log4cplus/ThreadPool |
| tokio | `tokio/rust-tokio-1.52.3.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/tokio-rs/tokio |
| tokio-stream | `tokio-stream/rust-tokio-stream-0.1.18.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/tokio-rs/tokio |
| tonic | `tonic/rust-tonic-0.14.6.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/hyperium/tonic |
| tonic-prost | `tonic-prost/rust-tonic-prost-0.14.6.txt` | Retain the copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://github.com/hyperium/tonic |
| uuid | `uuid/rust-uuid-1.29.0.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/uuid-rs/uuid |
| vsag | `vsag/vsag-LICENSE.txt` | Retain the Apache-2.0 text and the modification notices. The applied patches are recorded in the seekdb-deps repository under packages/vsag/0.16.20/patches. | https://github.com/antgroup/vsag |
| walkdir | `walkdir/rust-walkdir-2.5.0.txt` | Retain the supplied texts; using the MIT option requires its copyright and permission notice. | https://github.com/BurntSushi/walkdir |
| windows-sys | `windows-sys/rust-windows-sys-0.61.2.txt` | Retain the supplied dual-license texts and any applicable notices. Only the version with a staged text is listed here. | https://github.com/microsoft/windows-rs |
| x509-parser | `x509-parser/rust-x509-parser-0.18.1.txt` | Retain the supplied dual-license texts and any applicable notices. | https://github.com/rusticata/x509-parser |
| xxHash | `xxhash/xxhash-LICENSE.txt` | Reproduce the copyright, conditions, and disclaimer; no source or relink offer is required for unmodified binaries. | https://github.com/Cyan4973/xxHash |
| XZ Utils | `xz-utils/xz-COPYING.txt` | Retain the complete XZ licensing text and identify any LGPL/GPL components. | https://tukaani.org/xz/ |
| zlib | `zlib/zlib.txt` | Retain the notice, do not misrepresent origin, and mark altered source versions. | https://zlib.net/ |
| zlib-rs | `zlib-rs/rust-zlib-rs-0.6.8.txt` | Retain the notice, do not misrepresent origin, and mark altered source versions. | https://github.com/trifectatechfoundation/zlib-rs |
| zmij | `zmij/zmij.txt` | Retain the supplied copyright and permission notice; no source or relink offer is required for unmodified binaries. | https://crates.io/crates/zmij/1.0.23 |
| zstd-safe | `zstd-safe/zstd-safe.txt` | Reproduce the copyright, conditions, disclaimer, and non-endorsement term. | https://crates.io/crates/zstd-safe/8.2.0 |
| zstd-sys | `zstd-sys/zstd-sys.txt` | Reproduce the Meta copyright, conditions, disclaimer, and non-endorsement term. | https://crates.io/crates/zstd-sys/2.1.2+zstd.1.5.7 |

## General rules

- Keep `LICENSE`, `NOTICE`, this file, `THIRD_PARTY_COMPONENTS.md`, and
  the complete `licenses/` directory together.
- Do not rewrite upstream license or notice text.  If a component is
  modified, retain its notice and record the modification in the source
  repository.
- If a component is covered by a copyleft license and is bundled, follow
  its source and relink/replacement requirements.  `SOURCE-OFFER.txt`
  records the known offers.
- Separately installed dependencies are not bundled by this package.  A
  downstream application that redistributes them must preserve the license
  materials from the exact resolved versions.
